package com.impl.mycomposite.controller;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.impl.mycomposite.model.Customer;
import com.impl.mycomposite.service.CustomerService;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixProperty;

@RestController
public class CustomerCompositeController {
	@Autowired
	CustomerService service;
	
	@GetMapping("/customers")
	@HystrixCommand(fallbackMethod = "customerGetCustomer", 
			commandProperties= {
					@HystrixProperty(name="execution.isolation.thread.timeoutInMilliseconds",value="10000"),
					@HystrixProperty(name="circuitBreaker.requestVolumeThreshold",value="2"),
					@HystrixProperty(name="circuitBreaker.errorThresholdPercentage",value="50"),
					@HystrixProperty(name="circuitBreaker.sleepWindowInMilliseconds",value="5000")
					
			},
			threadPoolKey="serviceAppPool",
			threadPoolProperties= {
							@HystrixProperty(name="coreSize",value="5"),
							@HystrixProperty(name="maxQueueSize",value="2")
					}
			)
    public String getCustomers() {
		return service.getCustomers();
	}
    
	@GetMapping("/customers/{customerId}")
	@HystrixCommand(fallbackMethod = "customerGetCustomerById")
    public String getCustomer(@PathVariable("customerId") int customerId) {
		return service.getCustomer(customerId);
	}
    
    @PostMapping("/addCustomer")
    @HystrixCommand(fallbackMethod = "customerAddCustomers", 
    		commandProperties= {
					@HystrixProperty(name="execution.isolation.thread.timeoutInMilliseconds",value="10000"),
					@HystrixProperty(name="circuitBreaker.requestVolumeThreshold",value="2"),
					@HystrixProperty(name="circuitBreaker.errorThresholdPercentage",value="50"),
					@HystrixProperty(name="circuitBreaker.sleepWindowInMilliseconds",value="5000")
					
			},
			threadPoolKey="serviceAppPool",
			threadPoolProperties= {
							@HystrixProperty(name="coreSize",value="5"),
							@HystrixProperty(name="maxQueueSize",value="2")
					}
    		)
    public String addCustomer(@RequestBody Customer customer) {
    	return service.addCustomer(customer);
    }
    
    @PutMapping("/customers/{customerId}")
    @HystrixCommand(fallbackMethod = "customerUpdateById")
    public String updateCustomer(@PathVariable("customerId") int customerId,@RequestBody Customer customer) {
    	return service.updateCustomer(customerId, customer);
    }
    
    @SuppressWarnings("unused")
    private String customerAddCustomers(@RequestBody Customer customer) { 
        return new String("CIRCUIT BREAKER ENABLED!!! No Response From customer Service at this moment. " +
                    " Service will be back shortly - " + new Date());
    }
    
    
    
    @SuppressWarnings("unused")
    private String customerGetCustomer() { 
    	 return new String("CIRCUIT BREAKER ENABLED!!! No Response From customer Service at this moment. " +
                 " Service will be back shortly - " + new Date());
    }
    
    
    
    @SuppressWarnings("unused")
    private String customerGetCustomerById(@PathVariable("customerId") int customerId) { 
    	 return new String("CIRCUIT BREAKER ENABLED!!! No Response From customer Service at this moment. " +
                 " Service will be back shortly - " + new Date());
    }
    
    
    
    @SuppressWarnings("unused")
    private String customerUpdateById(@PathVariable("customerId") int customerId) { 
    	 return new String("CIRCUIT BREAKER ENABLED!!! No Response From customer Service at this moment. " +
                 " Service will be back shortly - " + new Date());
    }
}
