package com.impl.product.product.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;


@RefreshScope
@RestController
public class ProductController {
	
	@Autowired
	private DiscoveryClient discoveryClient;

	@Value("${test}")
	String test;
	
	@Value("${server.port}")
	String port;
	
	@GetMapping("/greet")
	public String greet() {
		return test+" ("+port+")";
	}
	
	@GetMapping("/test")
	public String test() {
		discoveryClient.getInstances("PRODUCT-MICROSERVICE").forEach(obj -> {
			System.out.println(obj.getPort());
		});
		return "OK";
	}
	
	
}
