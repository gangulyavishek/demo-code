package com.impl.mycomposite.controller;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.impl.mycomposite.model.Customer;
import com.impl.mycomposite.service.CustomerService;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixProperty;

@RestController
public class CustomerCompositeController {
	@Autowired
	CustomerService service;
	
	@GetMapping("/customers")
	@HystrixCommand(fallbackMethod = "customerGetCustomer", 
			commandProperties= {
					@HystrixProperty(name="execution.isolation.thread.timeoutInMilliseconds",value="8000"),
					@HystrixProperty(name="circuitBreaker.requestVolumeThreshold",value="2"),
					@HystrixProperty(name="circuitBreaker.errorThresholdPercentage",value="50"),
					@HystrixProperty(name="circuitBreaker.sleepWindowInMilliseconds",value="1000")
					
			},
			threadPoolKey="serviceAppPool",
			threadPoolProperties= {
							@HystrixProperty(name="coreSize",value="5"),
							@HystrixProperty(name="maxQueueSize",value="2")
					}
			)
    public ResponseEntity<Object> getCustomers() {
		return service.getCustomers();
	}
    
	@GetMapping("/customers/{customerId}")
	@HystrixCommand(fallbackMethod = "customerGetCustomerById")
    public ResponseEntity<Object> getCustomer(@PathVariable("customerId") int customerId) {
		return service.getCustomer(customerId);
	}
    
    @PostMapping("/addCustomer")
    @HystrixCommand(fallbackMethod = "customerAddCustomers", 
    		commandProperties= {
					@HystrixProperty(name="execution.isolation.thread.timeoutInMilliseconds",value="2000"),
					@HystrixProperty(name="circuitBreaker.requestVolumeThreshold",value="2"),
					@HystrixProperty(name="circuitBreaker.errorThresholdPercentage",value="50"),
					@HystrixProperty(name="circuitBreaker.sleepWindowInMilliseconds",value="1000")
					
			},
			threadPoolKey="serviceAppPool",
			threadPoolProperties= {
							@HystrixProperty(name="coreSize",value="5"),
							@HystrixProperty(name="maxQueueSize",value="2")
					}
    		)
    public ResponseEntity<Object> addCustomer(@RequestBody Customer customer) {
    	return new ResponseEntity<Object> (service.addCustomer(customer), HttpStatus.ACCEPTED);
    }
    
    @PutMapping("/customers/{customerId}")
    @HystrixCommand(fallbackMethod = "customerUpdateById")
    public ResponseEntity<Object> updateCustomer(@PathVariable("customerId") int customerId,@RequestBody Customer customer) {
    	return service.updateCustomer(customerId, customer);
    }
    
    @SuppressWarnings("unused")
    private ResponseEntity<Object> customerAddCustomers(@RequestBody Customer customer) { 
        return new ResponseEntity<Object> ("CIRCUIT BREAKER ENABLED!!! No Response From customer Service at this moment. " +
                    " Service will be back shortly - " + new Date(), HttpStatus.GATEWAY_TIMEOUT);
    }
    
    
    
    @SuppressWarnings("unused")
    private ResponseEntity<Object> customerGetCustomer() { 
        return new ResponseEntity<Object> ("CIRCUIT BREAKER ENABLED!!! No Response From customer Service at this moment. " +
                    " Service will be back shortly - " + new Date(), HttpStatus.GATEWAY_TIMEOUT);
    }
    
    
    
    @SuppressWarnings("unused")
    private ResponseEntity<Object> customerGetCustomerById(@PathVariable("customerId") int customerId) { 
        return new ResponseEntity<Object> ("CIRCUIT BREAKER ENABLED!!! No Response From customer Service at this moment. " +
                    " Service will be back shortly - " + new Date(), HttpStatus.GATEWAY_TIMEOUT);
    }
    
    
    
    @SuppressWarnings("unused")
    private ResponseEntity<Object> customerUpdateById(@PathVariable("customerId") int customerId) { 
        return new ResponseEntity<Object> ("CIRCUIT BREAKER ENABLED!!! No Response From customer Service at this moment. " +
                    " Service will be back shortly - " + new Date(), HttpStatus.GATEWAY_TIMEOUT);
    }
}
