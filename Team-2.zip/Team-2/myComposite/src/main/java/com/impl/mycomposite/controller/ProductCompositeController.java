package com.impl.mycomposite.controller;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.impl.mycomposite.model.Customer;
import com.impl.mycomposite.model.Product;
import com.impl.mycomposite.service.ProductService;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@RestController
public class ProductCompositeController {
	@Autowired
	ProductService prdService;

	@PostMapping("/addProduct")
    @HystrixCommand(fallbackMethod = "customerAddProducts")
	public ResponseEntity<Product> addProduct(@RequestBody Product product) {
    	return prdService.addProduct(product);
    }
    
    @GetMapping(path="/products")
    @HystrixCommand(fallbackMethod = "productGetProduct")
	public ResponseEntity<Object> getProducts() {
    	return prdService.getProducts();
    }
    
    @GetMapping(path="/products/{productId}")
    @HystrixCommand(fallbackMethod = "getByPrdId")
	public ResponseEntity<Object> getProduct(@PathVariable("productId") int productId) {
    	return prdService.getProduct(productId);
    }
    
    @PutMapping("/products/{productId}")
    @HystrixCommand(fallbackMethod = "getByPrdIdUpd")
	public ResponseEntity<Object> updateProduct(@PathVariable("productId") int productId,@RequestBody Product product) {
    	return prdService.updateProduct(productId, product);
    }
    
    @DeleteMapping(path="/deleteAll")
    @HystrixCommand(fallbackMethod = "deleteFallback")
	public ResponseEntity<Object> deleteAll() {
    	return prdService.deleteAll();
    }
    
    @DeleteMapping("/deleteProduct/{productId}")
    @HystrixCommand(fallbackMethod = "prdDelById")
	public String deleteProduct(@PathVariable("productId") int productId) {
    	return prdService.deleteProduct(productId);
    }
    
    
    @SuppressWarnings("unused")
    private ResponseEntity<Object> customerAddProducts(@RequestBody Customer customer) { 
        return new ResponseEntity<Object> ("CIRCUIT BREAKER ENABLED!!! No Response From product Service at this moment. " +
                    " Service will be back shortly - " + new Date(), HttpStatus.GATEWAY_TIMEOUT);
    }
    
    
    
    @SuppressWarnings("unused")
    private ResponseEntity<Object> productGetProduct() { 
        return new ResponseEntity<Object> ("CIRCUIT BREAKER ENABLED!!! No Response From product Service at this moment. " +
                    " Service will be back shortly - " + new Date(), HttpStatus.GATEWAY_TIMEOUT);
    }
    
    
    
    @SuppressWarnings("unused")
    private ResponseEntity<Object> getByPrdId(@PathVariable("customerId") int customerId) { 
        return new ResponseEntity<Object> ("CIRCUIT BREAKER ENABLED!!! No Response From product Service at this moment. " +
                    " Service will be back shortly - " + new Date(), HttpStatus.GATEWAY_TIMEOUT);
    }
    
    @SuppressWarnings("unused")
    private ResponseEntity<Object> getByPrdIdUpd(@PathVariable int productId,@RequestBody Product product) { 
        return new ResponseEntity<Object> ("CIRCUIT BREAKER ENABLED!!! No Response From product Service at this moment. " +
                    " Service will be back shortly - " + new Date(), HttpStatus.GATEWAY_TIMEOUT);
    }
    
    
    
    @SuppressWarnings("unused")
    private ResponseEntity<Object> prdDelById(@PathVariable("productId") int productId) { 
        return new ResponseEntity<Object> ("CIRCUIT BREAKER ENABLED!!! No Response From product Service at this moment. " +
                    " Service will be back shortly - " + new Date(), HttpStatus.GATEWAY_TIMEOUT);
    }
}
