package com.impl.zuulapigateway.zuulapigateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZuulapigatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
